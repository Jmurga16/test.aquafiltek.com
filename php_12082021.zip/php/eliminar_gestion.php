<?php
session_start();
$arr_respuesta = ['error'=>true,'msj'=>''];

if(!isset($_SESSION['ide']) || $_SESSION['ide'] == NULL){
    $arr_respuesta['msj']='Debe iniciar sesión';
    echo json_encode($arr_respuesta);

    exit();
}
include "connect.php";


$id_gestion = $_POST['id_gestion'];


$script = "UPDATE `DatosClientes` SET `comentarios`='$comentHistorico',`comentarios_gestion`='$comentFinal',`estado`='Acepto' WHERE codigo='$id_cliente'";
mysqli_query($enlace, $script);

$puede = 1;


$sql = "SELECT * from Gestion_acepto WHERE primaryk = '$id_gestion'";

$resultado = mysqli_query($enlace, $sql);
if($resultado){
    $num_filas=0;
    while ($fila_aux = mysqli_fetch_array($resultado)) {
       $num_filas++;
    }
    
    if( $num_filas == 1 ){
        $script = "DELETE FROM  `Gestion_acepto` WHERE  primaryk = '$id_gestion'";
	    $result = mysqli_query($enlace, $script);
	    if (!$result){
	        $arr_respuesta['msj'] = 'Error al eliminar gestión';
	    }
	    else{
	        file_put_contents('log_delete_geston_'.date('Ymd').'.log', $script, FILE_APPEND );
	        $arr_respuesta['error'] = false;
	        $arr_respuesta['msj'] = 'Gestión eliminada';
	    }

    }
    else if( $num_filas == 0){
        $arr_respuesta['msj'] = 'No hay registros con id Gestión :'.$id_gestion;
    }
    else{
        $arr_respuesta['msj'] = 'Hay más de un resultado con id:'.$id_gestion;
    }
	
}
else{
    $arr_respuesta['msj'] = 'No hay registros con id Gestión :'.$id_gestion;
}
echo json_encode($arr_respuesta);

?>