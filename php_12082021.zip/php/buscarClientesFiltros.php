<?php
session_start();
$arr_respuesta = ['error'=>true,'msj'=>''];

if(!isset($_SESSION['ide']) || $_SESSION['ide'] == NULL){
    $arr_respuesta['msj']='Debe iniciar sesión';
    echo json_encode($arr_respuesta);

    exit();
}
include "connect.php";
$filtros = isset($_POST['filtros'])?$_POST['filtros']:[];
$fecha_inicio = isset($_POST['fecha_inicio'])?$_POST['fecha_inicio']:'';
$fecha_fin = isset($_POST['fecha_fin'])?$_POST['fecha_fin']:'';

$sql = "SELECT codigo, nombre_completo, Datos_factura, direccion, fecha_gestion from DatosClientes WHERE 1 ";
if($fecha_inicio != '')
$sql .= " AND fecha_gestion >= '".$fecha_inicio."'";
if($fecha_fin != '')
$sql .= " AND fecha_gestion <= '".$fecha_fin."'";
$arr_condiciones = [];
if( count($filtros) > 0){
    $sql .= " AND ( ";
    foreach($filtros as $filtro){
        $arr_condiciones[]= " estado = '".$filtro."' ";
    }
    $str_condiciones = implode(' OR ',$arr_condiciones); 
    $sql .= $str_condiciones. " ) ";
    
}
$sql.=" ORDER BY fecha_gestion DESC, nombre_completo ASC LIMIT 50 ";
$arr_respuesta['sql']=$sql;
$resultado = mysqli_query($enlace, $sql);
if($resultado){
    $num_filas=0;
    while ($fila = mysqli_fetch_array($resultado)) {
       $cliente["codigo"] = $fila["codigo"];
       $cliente["nombre_completo"] = $fila["nombre_completo"];
       $cliente["datos_factura"] = $fila["Datos_factura"];
       $cliente["direccion"] = $fila["direccion"];
       $cliente["fecha_gestion"] = $fila["fecha_gestion"];
       $arr_respuesta['filas'][] = $cliente;
       
    }
    $arr_respuesta['error'] = false;
    $arr_respuesta['numero_filas'] = $num_filas;
    
	
}
else{
    $arr_respuesta['msj'] = 'Error al obtener datos de tira informativa ';
}
echo json_encode($arr_respuesta);

?>