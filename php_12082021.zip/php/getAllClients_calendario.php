<?php
include("connect.php");
//$minima_fecha = date("-2 days");
//$date = "2015-11-17";
$anio_actual = date("Y"); 
$minima_fecha = date('Y-m-d', strtotime(date("Y-m-d"). ' - 3 days'));
    
$hoy = date('Y-m-d');
$script="SELECT primaryk,`codigo`,`coordenadas`, `nombre_completo`, fecha_acepto, hora_acepto FROM `DatosClientes` 
LEFT JOIN Gestion_acepto ON Gestion_acepto.codigo_cliente = DatosClientes.codigo WHERE actual_gestion=0 
AND STR_TO_DATE(Gestion_acepto.fecha_acepto,'%d/%m/%Y') < '".$hoy."' GROUP BY Gestion_acepto.codigo_cliente
ORDER BY Gestion_acepto.primaryk DESC, STR_TO_DATE(Gestion_acepto.fecha_acepto+' '+Gestion_acepto.hora_acepto,'%d/%m/%Y %H:%i:%s') DESC LIMIT 5"; //coordenadas

/*	
SELECT primaryk,`codigo`,`coordenadas`, `nombre_completo`, fecha_acepto, hora_acepto FROM `DatosClientes` 
LEFT JOIN Gestion_acepto ON Gestion_acepto.codigo_cliente = DatosClientes.codigo WHERE actual_gestion=0 
AND STR_TO_DATE(Gestion_acepto.fecha_acepto,'%d/%m/%Y') < '2021-08-05' GROUP BY Gestion_acepto.codigo_cliente
ORDER BY Gestion_acepto.primaryk DESC, STR_TO_DATE(Gestion_acepto.fecha_acepto+' '+Gestion_acepto.hora_acepto,'%d/%m/%Y %H:%i:%s') DESC LIMIT 3
*/
//echo $script; exit();
//AND YEAR(STR_TO_DATE(Gestion_acepto.fecha_acepto,'%d/%m/%Y'))=".$anio_actual."
//STR_TO_DATE(Gestion_acepto.fecha_acepto,'%d/%m/%Y') <= '".$hoy."' AND STR_TO_DATE(Gestion_acepto.fecha_acepto,'%d/%m/%Y')  >='".$minima_fecha."'  

$resultado=mysqli_query($enlace, $script);

while ($fila = mysqli_fetch_array($resultado)) {
    if( trim($fila['codigo']) != "" )
    echo $fila['codigo']."|".$fila['coordenadas']."|".$fila['nombre_completo']."|".$fila['fecha_acepto']."|".$fila['hora_acepto']."=";
}
include("QuitDB.php");
