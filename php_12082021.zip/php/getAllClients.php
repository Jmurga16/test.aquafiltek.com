<?php
include("connect.php");
$hoy = date('Y-m-d');
$script="SELECT dc.`codigo`,dc.`coordenadas`, dc.`nombre_completo` FROM `DatosClientes` as dc JOIN Gestion_acepto AS ga ON dc.codigo = ga.codigo_cliente WHERE 
        STR_TO_DATE(ga.fecha_acepto,'%d/%m/%Y') <= '$hoy' WHERE actual_gestion=0 ORDER BY coordenadas"; 
$resultado=mysqli_query($enlace, $script);

while ($fila = mysqli_fetch_array($resultado)) {
    if( trim($fila['codigo']) != "" )
    echo $fila['codigo']."|".$fila['coordenadas']."|".$fila['nombre_completo']."=";
}
include("QuitDB.php");
