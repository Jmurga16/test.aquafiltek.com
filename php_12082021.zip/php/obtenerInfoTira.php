<?php
session_start();
$arr_respuesta = ['error'=>true,'msj'=>''];

if(!isset($_SESSION['ide']) || $_SESSION['ide'] == NULL){
    $arr_respuesta['msj']='Debe iniciar sesión';
    echo json_encode($arr_respuesta);

    exit();
}
include "connect.php";



$sql = "SELECT * from tipos_gestion";
$resultado = mysqli_query($enlace, $sql);
$arr_gestiones = [];
if($resultado){
    while ($fila = mysqli_fetch_array($resultado)) {
        $arr_gestiones[] = ['id'=>$fila['id'], 'gestion'=>$fila['descripcion'],'cantidad'=>0];
    }
}
else{
    $arr_respuesta['q1']=mysqli_error($enlace);
}
$sql = "SELECT * from clientes_gestionados_otros WHERE id_operador = ".$_SESSION['ide'];
$arr_respuesta['g'] = $arr_gestiones;
$arr_respuesta['d']=[]; 

$resultado = mysqli_query($enlace, $sql);
if($resultado){
    while ($fila = mysqli_fetch_array($resultado)) {
      //$arr_respuesta['d'][] = $fila;
      $key = array_search($fila['id_tipo_gestion'], array_column($arr_gestiones, 'id'));
      $arr_gestiones[$key]['cantidad']++;
       
    }
    $arr_respuesta['gestiones']=$arr_gestiones;
    $arr_respuesta['error'] = false;
    
	
}
else{
    $arr_respuesta['msj'] = 'Error al obtener datos de operador ';
}
echo json_encode($arr_respuesta);

?>