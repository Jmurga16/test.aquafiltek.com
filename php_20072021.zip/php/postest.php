<?php 
echo "--recibe post";
var_dump($_POST);

?>