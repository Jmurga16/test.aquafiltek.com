<?php 
mysqli_close($enlace);
 ?>